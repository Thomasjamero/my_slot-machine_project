/* ==========================================================
   SLOT MACHINE GAME LOGIC
   Handles: symbol data, randomness, spinning animation,
   win detection, and credit/bet management.
   ========================================================== */

// List of possible symbols. Each is an image path (used as reel.src).
const symbols = [
  "Monkey-Selfie (1).webp",
  "images (1).jfif",
  "monkey-800x600.jpg",
  "images (2).jfif",
  "Green_Screen_monkey_crying-0.webp",
  "giphy_s.gif"
];

// Payout multiplier for landing three-of-a-kind of each symbol.
// Rarer/harder symbols (like seven) pay more.
const payouts = {
  "Monkey-Selfie (1).webp": 2,
  "images (1).jfif": 3,
  "monkey-800x600.jpg": 5,
  "images (2).jfif": 8,
  "Green_Screen_monkey_crying-0.webp": 15,
  "giphy_s.gif": 30
};

// ---- Game state ----
let credits = 1000; // player's starting balance
let bet = 10;       // amount wagered per spin

// Chance that a spin is rigged to be a win (three matching symbols).
// 0.25 = 25% of spins will win.
const WIN_CHANCE = 0.25;

// ---- Cache DOM elements so we don't query them repeatedly ----
const reels = [
  document.getElementById("reel0"),
  document.getElementById("reel1"),
  document.getElementById("reel2")
];
const creditsEl = document.getElementById("credits");
const msgEl = document.getElementById("message");
const betVal = document.getElementById("betVal");
const spinBtn = document.getElementById("spinBtn");
const paytableEl = document.getElementById("paytable");

// ---- Himoa ang paytable UI gamit ang payouts object ----
// Kini naglikay sa pag-hardcode sa paytable sa HTML aron pirming
// magkatugma kini ug awtomatikong ma-update kung mausab ang
// mga simbolo o payouts.
paytableEl.innerHTML =
  Object.entries(payouts)
    .map(([sym, mult]) => `
      <div>
        <span>
          <img class="pay-icon" src="${sym}" alt="">
          <img class="pay-icon" src="${sym}" alt="">
          <img class="pay-icon" src="${sym}" alt="">
        </span>
        <span>x${mult}</span>
      </div>
    `)
    .join("");

// ---- Bet controls ----
document.getElementById("betUp").onclick = () => {
  if (bet < 50) {
    bet += 5;
    betVal.textContent = bet;
  }
};

document.getElementById("betDown").onclick = () => {
  if (bet > 5) {
    bet -= 5;
    betVal.textContent = bet;
  }
};

// Returns a random symbol image path from the symbols array.
// Used for the spinning animation frames (purely visual, not the
// final result).
function randomSymbol() {
  return symbols[Math.floor(Math.random() * symbols.length)];
}

// Decides the final three symbols for a spin, weighted toward
// WIN_CHANCE so that roughly that fraction of spins are wins.
// - On a "win" roll: pick one random symbol and repeat it three times.
// - On a "loss" roll: pick three symbols and guarantee they are NOT
//   all the same (re-rolls until at least one differs).
function generateResults() {
  const isWin = Math.random() < WIN_CHANCE;

  if (isWin) {
    const sym = randomSymbol();
    return [sym, sym, sym];
  }

  let results;
  do {
    results = [randomSymbol(), randomSymbol(), randomSymbol()];
  } while (results[0] === results[1] && results[1] === results[2]);
  return results;
}

// Starts a spin: deducts the bet, animates each reel, then evaluates
// the final result once all reels have stopped.
function spin() {
  // Guard: don't allow spinning without enough credits
  if (credits < bet) {
    msgEl.textContent = "Not enough credits";
    return;
  }

  // Deduct bet up front
  credits -= bet;
  creditsEl.textContent = credits;

  // Disable the button during the spin animation to prevent double-clicks
  spinBtn.disabled = true;
  msgEl.textContent = "Spinning...";

  // Decide the final result for each reel in advance, weighted toward
  // a 25% win rate via generateResults()
  const results = generateResults();

  // Each reel spins a different number of times so they don't all
  // stop at once — this gives a more realistic staggered stop effect.
  const spinCounts = [10, 15, 20];
  const counters = [0, 0, 0];

  reels.forEach((reel, i) => {
    // setInterval repeatedly swaps the reel image to simulate spinning
    const interval = setInterval(() => {
      reel.src = randomSymbol();
      counters[i]++;

      // Once this reel has "spun" enough times, lock in its final result
      if (counters[i] >= spinCounts[i]) {
        clearInterval(interval);
        reel.src = results[i];

        // Once the last reel stops, evaluate the full result
        if (i === reels.length - 1) {
          evaluate(results);
        }
      }
    }, 60); // spin speed in milliseconds
  });
}

// Compares the three reel results and pays out credits accordingly.
// Only three matching symbols count as a win — two matching symbols
// (a pair) does NOT win anything.
function evaluate(results) {
  let win = 0;

  if (results[0] === results[1] && results[1] === results[2]) {
    // All three symbols match -> win, pays based on that symbol's multiplier
    win = bet * payouts[results[0]];
    msgEl.textContent = "Jackpot💸! +" + win;
  } else {
    // Anything else (including a pair) -> no payout
    msgEl.textContent = "You loss😭";
  }

  // Update credits and re-enable the spin button
  credits += win;
  creditsEl.textContent = credits;
  spinBtn.disabled = false;

  if (credits <= 0) {
    msgEl.textContent = "Out of credits pls doposit";
  }
}

// Hook up the spin button
spinBtn.onclick = spin;