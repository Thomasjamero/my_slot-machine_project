# Slot Machine Project

## Team Members

| Name | Student ID |
|---|---|
| Thomas Llagas Jamero | 02-2425-014020 |

## Project Files

- `Kulas.html` — Main HTML structure for the slot machine
- `Mark.css` — Stylesheet for layout and visuals
- `Tomas.js` — Game logic and functionality

## Description

A browser-based slot machine game built with HTML, CSS, and JavaScript.
